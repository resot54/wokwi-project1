#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// Инициализация LCD (адрес 0x27, 16 символов, 2 строки)
LiquidCrystal_I2C lcd(0x27, 16, 2);

const int buttonPin = 2;  // Пин кнопки
int lastButtonState = HIGH;
int currentButtonState;

// Рекурсивная функция вычисления числа Фибоначчи
unsigned long fibonacci(int n) {
  if (n <= 1) {
    return n;
  } else {
    return fibonacci(n - 1) + fibonacci(n - 2);
  }
}

void setup() {
  // Инициализация последовательного порта для отладки
  Serial.begin(9600);
  
  // Инициализация LCD
  lcd.init();
  lcd.backlight();
  
  // Настройка пина кнопки с подтяжкой
  pinMode(buttonPin, INPUT_PULLUP);
  
  // Приветственное сообщение
  lcd.setCursor(0, 0);
  lcd.print("Press button");
  lcd.setCursor(0, 1);
  lcd.print("to start");
}

void loop() {
  currentButtonState = digitalRead(buttonPin);
  
  // Обработка нажатия кнопки (антидребезг не требуется из‑за медленного цикла)
  if (currentButtonState == LOW && lastButtonState == HIGH) {
    delay(100);  // Антидребезг
    
    // Генерация случайного числа в диапазоне 5–30
    int randomNumber = random(5, 31);  // 31, потому что верхняя граница исключается
    
    // Вывод случайного числа на первую строку
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Num: ");
    lcd.print(randomNumber);
    
    // Замер времени выполнения
    unsigned long startTime = micros();
    unsigned long fibResult = fibonacci(randomNumber);
    unsigned long endTime = micros();
    
    // Расчёт времени в секундах (с точностью до 5 знаков после запятой)
    float timeSeconds = (endTime - startTime) / 1000000.0;
    
    // Вывод времени на вторую строку
    lcd.setCursor(0, 1);
    lcd.print("Time: ");
    lcd.print(timeSeconds, 5);  // 5 знаков после запятой
    lcd.print(" sec");
    
    // Вывод числа Фибоначчи на третью строку
    lcd.setCursor(0, 2);
    lcd.print("Fib: ");
    lcd.print(fibResult);
    
    Serial.print("Random number: ");
    Serial.println(randomNumber);
    Serial.print("Fibonacci result: ");
    Serial.println(fibResult);
    Serial.print("Execution time: ");
    Serial.print(timeSeconds, 6);
    Serial.println(" seconds");
  }
  
  lastButtonState = currentButtonState;
  delay(100);  // Задержка для стабильности
}
